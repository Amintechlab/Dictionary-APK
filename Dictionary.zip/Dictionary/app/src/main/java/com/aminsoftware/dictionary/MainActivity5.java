package com.aminsoftware.dictionary;


import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.AdapterStatus;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.util.Map;


public class MainActivity5 extends Activity {

    AdView adView;

    TextView button_clear,button_Copy,button_click;
    EditText text_view;

    Uri imageUri;
    TextRecognizer textRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);


        button_clear = findViewById(R.id.button_clear);
        button_Copy = findViewById(R.id.button_Copy);
        text_view = findViewById(R.id.text_view);
        button_click = findViewById(R.id.button_click);
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);


//==================================================================================================
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
                Map<String, AdapterStatus> statusMap = initializationStatus.getAdapterStatusMap();
                for (String adapterClass : statusMap.keySet()) {
                    AdapterStatus status = statusMap.get(adapterClass);
                    Log.d("MyApp", String.format(
                            "Adapter name: %s, Description: %s, Latency: %d",
                            adapterClass, status.getDescription(), status.getLatency()));
                }
                // Start loading ads here...
                adView=findViewById(R.id.adView);
                MobileAds.initialize(getBaseContext(), new OnInitializationCompleteListener() {
                    @Override
                    public void onInitializationComplete( InitializationStatus initializationStatus) {

                    }
                });

                AdRequest adRequest=new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        });
//====================================================================================

        button_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ImagePicker.with(MainActivity5.this)
                        .crop()	    			//Crop image(Optional), Check Customization for more option
                        .compress(1024)			//Final image size will be less than 1 MB(Optional)
                        .maxResultSize(1080, 1080)	//Final image resolution will be less than 1080 x 1080(Optional)
                        .start();

            }
        });

        button_Copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String text = text_view.getText().toString();
                if (text.isEmpty()){
                    Toast.makeText(MainActivity5.this,"There is no text to copy", Toast.LENGTH_SHORT).show();
                }else {
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(MainActivity5.this.CLIPBOARD_SERVICE);
                    ClipData clipData = ClipData.newPlainText("Data",text_view.getText().toString());
                    clipboardManager.setPrimaryClip(clipData);

                    Toast.makeText(MainActivity5.this,"Text Copy to Clipboard", Toast.LENGTH_SHORT).show();

                }

            }
        });


    button_clear.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String text = text_view.getText().toString();

            if (text.isEmpty()){
                Toast.makeText(MainActivity5.this,"There is no text to clear", Toast.LENGTH_SHORT).show();
            }else {
                text_view.setText("");
            }

        }
    });



    }//..............

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            //Image Uri will not be null for RESULT_OK
            if (data!=null){
                imageUri = data.getData();
                Toast.makeText(this,"image select", Toast.LENGTH_SHORT).show();

                recognizeText();

            }
        } else {

            Toast.makeText(this,"image not select", Toast.LENGTH_SHORT).show();
        }

    }

    private void recognizeText() {

        if (imageUri!=null){
            try {
                InputImage inputImage = InputImage.fromFilePath(MainActivity5.this,imageUri);

                Task<Text> result = textRecognizer.process(inputImage)
                        .addOnSuccessListener(new OnSuccessListener<Text>() {
                            @Override
                            public void onSuccess(Text text) {

                                String recognizeText = text.getText();
                                text_view.setText(recognizeText);

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                Toast.makeText(MainActivity5.this,e.getMessage(), Toast.LENGTH_SHORT).show();

                            }
                        });

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }


}//......................