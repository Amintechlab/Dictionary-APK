package com.aminsoftware.dictionary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class QuestionCollection extends AppCompatActivity {
    RadioGroup radioGroup;
    TextView lblQuestion;
    RadioButton optionA;
    RadioButton optionB;
    RadioButton optionC;
    RadioButton optionD;
    Button confirm;
    String rightAnswer;
    String Answer;
    public static List<QuestionModule> question_list;
    int score;
    public static String SUBJECT_NAME = "";
    public static ArrayList <ArrayList<QuestionModule>> questionBank = new ArrayList<>();
    public static ArrayList <HashMap<String, String>> subjectList = new ArrayList<>();
    LinearLayout rootLay;

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    String myRightAns;
    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);


        rootLay = findViewById(R.id.rootLay);
        confirm = findViewById(R.id.confirm);
        lblQuestion = findViewById(R.id.lblPergunta);
        optionA = findViewById(R.id.opcaoA);
        optionB = findViewById(R.id.opcaoB);
        optionC = findViewById(R.id.opcaoC);
        optionD = findViewById(R.id.opcaoD);
        score = 0;
        radioGroup = findViewById(R.id.radioGroup);
        loadQuestion();

    }

    @Override
    protected void onRestart(){
        super.onRestart();
        loadQuestion();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(rootLay!=null) rootLay.startAnimation(AnimationUtils.loadAnimation(QuestionCollection.this, R.anim.middle_to_top));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void loadQuestion(){
        //Toast.makeText(getApplicationContext(), "Total Questions: "+question_list.size(), Toast.LENGTH_SHORT).show();
        if(question_list.size() > 0) {
            QuestionModule q = question_list.remove(0);
            lblQuestion.setText(q.getQuestion());
            List<String> answers = q.getAnswers();

            optionA.setText(answers.get(0));
            optionB.setText(answers.get(1));
            optionC.setText(answers.get(2));
            optionD.setText(answers.get(3));
            rightAnswer = q.getRightAnswer();

 //============================================================
            if (rightAnswer.contains("A")){
                myRightAns= optionA.getText().toString();
            }else if (rightAnswer.contains("B")){
                myRightAns = optionB.getText().toString();
            }else if (rightAnswer.contains("C")){
                myRightAns= optionC.getText().toString();
            }else if (rightAnswer.contains("D")) {
                myRightAns = optionD.getText().toString();
            }else {
                myRightAns="No Option";
            }
 //==========================================================




        } else {
            Intent intent = new Intent(this, ScoreActivity.class);
            intent.putExtra("score", score);
            startActivity(intent);
            finish();
        }
    }

    public void loadAnswer(View view) {
        int op = radioGroup.getCheckedRadioButtonId();

        switch (op){
            case R.id.opcaoA:
                Answer="A";
                break;

            case R.id.opcaoB:
                Answer="B";
                break;

            case R.id.opcaoC:
                Answer="C";
                break;

            case R.id.opcaoD:
                Answer="D";
                break;

            default:
                return;

        }

        radioGroup.clearCheck();

        this.startActivity(isRightOrWrong(Answer));

    }

    private Intent isRightOrWrong(String Answer){
        Intent screen;
        if(Answer.equals(rightAnswer)) {
            this.score += 1;
            screen = new Intent(this, RightActivity.class);

        }else {
            screen = new Intent(this, WrongActivity.class);
            WrongActivity.my_RIGHT_Ans= myRightAns;
        }

        return screen;
    }


    //====================================================================
    public static  ArrayList <QuestionModule> questions;
    public static void createQuestionBank(){
        QuestionCollection.subjectList = new ArrayList<>();
        QuestionCollection.questionBank = new ArrayList<>();






        questions = new ArrayList(){
            {
                add(new QuestionModule("বিশ্বের সবচেয়ে বড় মহাসাগর কোনটি?", "C", "আটলান্টিক মহাসাগর", "ভারত মহাসাগর", "প্রশান্ত মহাসাগর", "আর্কটিক মহাসাগর"));
                add(new QuestionModule("গ্রেট ব্যারিয়ার রিফ কোথায় অবস্থিত?", "A", "অস্ট্রেলিয়া", "মালদ্বীপ", "ফিজি", "নিউজিল্যান্ড"));
                add(new QuestionModule("বিশ্বের গভীরতম সাগরের নাম কী?", "B", "আর্কটিক সাগর", "মারিয়ানা ট্রেঞ্চ", "ক্যারিবিয়ান সাগর", "রেড সি"));
                add(new QuestionModule("আর্কটিক মহাসাগর কোথায় অবস্থিত?", "A", "উত্তর মেরু", "দক্ষিণ মেরু", "প্রশান্ত মহাসাগর", "আটলান্টিক মহাসাগর"));
                add(new QuestionModule("মৃত সাগরের জলের বিশেষত্ব কী?", "C", "এটি ঠান্ডা", "এটি মিষ্টি", "এটি অত্যন্ত লবণাক্ত", "এটি সবুজ রঙের"));
                add(new QuestionModule("বিশ্বের দীর্ঘতম সাগরপথের নাম কী?", "B", "উত্তর সাগরপথ", "দক্ষিণ সাগরপথ", "আটলান্টিক সাগরপথ", "প্যাসিফিক সাগরপথ"));
                add(new QuestionModule("বিশ্বের দ্বিতীয় বৃহত্তম মহাসাগর কোনটি?", "A", "আটলান্টিক মহাসাগর", "প্রশান্ত মহাসাগর", "ভারত মহাসাগর", "আর্কটিক মহাসাগর"));
                add(new QuestionModule("ক্যারিবিয়ান সাগর কোথায় অবস্থিত?", "B", "মধ্যপ্রাচ্য", "মধ্য আমেরিকা", "উত্তর আমেরিকা", "দক্ষিণ আমেরিকা"));
                add(new QuestionModule("কোন সাগরটি 'রহস্যময় সাগর' নামে পরিচিত?", "D", "বাল্টিক সাগর", "আলাস্কা সাগর", "কোরাল সাগর", "সারগাসো সাগর"));
                add(new QuestionModule("বিশ্বের প্রাচীনতম মহাসাগর কোনটি?", "A", "প্রশান্ত মহাসাগর", "আটলান্টিক মহাসাগর", "ভারত মহাসাগর", "আর্কটিক মহাসাগর"));
            }
        };
        QuestionModule.createQuestionsForSubject("সমুদ্র সম্পর্কে সাধারণ জ্ঞান", R.drawable.sea, questions);



        questions = new ArrayList(){
            {
                add(new QuestionModule("বিশ্বের সর্ববৃহৎ দেশ কোনটি?", "C", "চীন", "কানাডা", "রাশিয়া", "আমেরিকা"));
                add(new QuestionModule("আইফেল টাওয়ার কোথায় অবস্থিত?", "A", "প্যারিস", "লন্ডন", "বার্লিন", "রোম"));
                add(new QuestionModule("মানব শরীরের বৃহত্তম অঙ্গ কোনটি?", "B", "হৃদযন্ত্র", "চামড়া", "যকৃত", "ফুসফুস"));
                add(new QuestionModule("বিশ্ব স্বাস্থ্য সংস্থা (WHO) কোথায় অবস্থিত?", "D", "নিউইয়র্ক", "জেনেভা", "লন্ডন", "জেনেভা"));
                add(new QuestionModule("পৃথিবীর সবচেয়ে দ্রুততম প্রাণী কোনটি?", "A", "চিতা", "গ্রীনল্যান্ড হাঙর", "প্রশান্ত মহাসাগরীয় সালমোন", "হার্পুন মাছ"));
                add(new QuestionModule("প্রথম নোবেল পুরস্কার কোন বছর প্রদান করা হয়?", "C", "১৯০১", "১৯০৩", "১৯০৫", "১৯০৭"));
                add(new QuestionModule("বিশ্বের দীর্ঘতম নদী কোনটি?", "B", "আমাজন", "নীল নদ", "মিসিসিপি", "গঙ্গা"));
                add(new QuestionModule("বিশ্বের সবচেয়ে বেশি ভাষাভাষীর দেশ কোনটি?", "A", "পাপুয়া নিউ গিনি", "ভারত", "নাইজেরিয়া", "চীন"));
                add(new QuestionModule("অ্যালবার্ট আইনস্টাইন কোন তত্ত্বের জন্য বিখ্যাত?", "C", "বড় বিস্ফোরণ তত্ত্ব", "মহাকর্ষ তত্ত্ব", "আপেক্ষিকতার তত্ত্ব", "কোয়ান্টাম তত্ত্ব"));
                add(new QuestionModule("চাঁদের পৃষ্ঠে হাঁটা প্রথম মানুষ কে?", "D", "ইউরি গাগারিন", "মাইকেল কলিন্স", "বাজ অলড্রিন", "নীল আর্মস্ট্রং"));
            }
        };
        QuestionModule.createQuestionsForSubject("বিশ্ব সাধারণ জ্ঞান 1", R.drawable.cat1, questions);



        questions = new ArrayList(){
            {
                add(new QuestionModule("পৃথিবীর উচ্চতম পর্বত কোনটি?", "B", "কাঞ্চনজঙ্ঘা", "এভারেস্ট", "কিলিমাঞ্জারো", "মাউন্ট ফুজি"));
                add(new QuestionModule("প্রথম মানুষ কোন মহাদেশে ছিল?", "C", "এশিয়া", "ইউরোপ", "আফ্রিকা", "আমেরিকা"));
                add(new QuestionModule("গ্রেট ব্যারিয়ার রিফ কোথায় অবস্থিত?", "A", "অস্ট্রেলিয়া", "মালদ্বীপ", "ফিজি", "নিউজিল্যান্ড"));
                add(new QuestionModule("বিশ্বের সবচেয়ে বড় মহাসাগর কোনটি?", "C", "আটলান্টিক মহাসাগর", "ভারত মহাসাগর", "প্রশান্ত মহাসাগর", "আর্কটিক মহাসাগর"));
                add(new QuestionModule("পৃথিবীর সবচেয়ে বেশি জনসংখ্যার দেশ কোনটি?", "D", "আমেরিকা", "ভারত", "ইন্দোনেশিয়া", "চীন"));
                add(new QuestionModule("মৃত সাগরের জলের বিশেষত্ব কি?", "B", "এটি খুব ঠান্ডা", "এটি অত্যন্ত লবণাক্ত", "এটি সবুজ রঙের", "এটি অত্যন্ত উষ্ণ"));
                add(new QuestionModule("জীবাশ্ম জ্বালানি কোনটি নয়?", "D", "কয়লা", "পেট্রোল", "প্রাকৃতিক গ্যাস", "সৌরশক্তি"));
                add(new QuestionModule("বিশ্বের সবচেয়ে ছোট দেশ কোনটি?", "A", "ভ্যাটিকান সিটি", "মোনাকো", "নাউরু", "সান মারিনো"));
                add(new QuestionModule("পৃথিবীর বৃহত্তম মরুভূমি কোনটি?", "B", "আরবীয় মরুভূমি", "সাহারা", "গোবি", "ক্যালাহারি"));
                add(new QuestionModule("অস্কার পুরস্কার কোন ক্ষেত্রের জন্য দেওয়া হয়?", "C", "সাহিত্য", "সঙ্গীত", "চলচ্চিত্র", "বিজ্ঞান"));
            }
        };
        QuestionModule.createQuestionsForSubject("বিশ্ব সাধারণ জ্ঞান 2", R.drawable.cat1, questions);




        //------------- Subject 1
        questions = new ArrayList(){
            {
                add(new QuestionModule("বিশ্বের বৃহত্তম মহাসাগরের নাম কি?", "A", "প্রশান্ত মহাসাগর", "আটলান্টিক মহাসাগর", "ভারত মহাসাগর", "আর্কটিক মহাসাগর"));
                add(new QuestionModule("পৃথিবীর সর্বোচ্চ পর্বতের নাম কি?", "B", "কাঞ্চনজঙ্ঘা", "এভারেস্ট", "কিলিমাঞ্জারো", "মাকালু"));
                add(new QuestionModule("রাশিয়ার রাজধানীর নাম কি?", "C", "সেন্ট পিটার্সবার্গ", "নভোসিবির্স্ক", "মস্কো", "ইকাতেরিনবুর্গ"));
                add(new QuestionModule("মহাশূন্যে প্রথম যাত্রী ছিলেন কে?", "A", "ইউরি গাগারিন", "নীল আর্মস্ট্রং", "বাজ অলড্রিন", "ভ্যালেন্টিনা তেরেশকোভা"));
                add(new QuestionModule("পৃথিবীর বৃহত্তম বন্যপ্রাণী উদ্যান কোথায় অবস্থিত?", "D", "কেনিয়া", "ভারত", "অস্ট্রেলিয়া", "তানজানিয়া"));
                add(new QuestionModule("গ্রিসের প্রধান শহরের নাম কি?", "A", "এথেন্স", "সালোনিকা", "পাত্রা", "লারিসা"));
                add(new QuestionModule("নেপালের মুদ্রার নাম কি?", "C", "টাকা", "ডলার", "রুপি", "ইয়েন"));
                add(new QuestionModule("জার্মানির বিখ্যাত মহাসড়কের নাম কি?", "B", "মহাসড়ক", "অটোবাহ্ন", "হাইওয়ে", "ফ্রিওয়ে"));
                add(new QuestionModule("বিশ্বের বৃহত্তম মরুভূমির নাম কি?", "A", "সাহারা", "গোবি", "ক্যালাহারি", "অ্যারাবিয়ান"));
                add(new QuestionModule("জলবায়ু পরিবর্তনের জন্য প্রধানত কোন গ্যাসটি দায়ী?", "D", "নাইট্রোজেন", "হাইড্রোজেন", "অক্সিজেন", "কার্বন ডাই অক্সাইড"));
            }
        };
        QuestionModule.createQuestionsForSubject("বিশ্ব জ্ঞান", R.drawable.cat8, questions);




        //------------- Subject 2
        questions = new ArrayList(){
            {
                add(new QuestionModule("বাংলাদেশের প্রথম প্রধানমন্ত্রী কে ছিলেন?", "A", "তাজউদ্দীন আহমদ", "শেখ মুজিবুর রহমান", "জিয়াউর রহমান", "হোসেন শহীদ সোহরাওয়ার্দী"));
                add(new QuestionModule("বাংলাদেশের জাতীয় ফুল কোনটি?", "B", "গোলাপ", "শাপলা", "জবা", "বকুল"));
                add(new QuestionModule("বাংলাদেশের সর্ববৃহৎ জেলা কোনটি?", "D", "চট্টগ্রাম", "কুমিল্লা", "রংপুর", "রাঙ্গামাটি"));
                add(new QuestionModule("বাংলাদেশের জাতীয় সংগীত 'আমার সোনার বাংলা' কে রচনা করেছেন?", "C", "কাজী নজরুল ইসলাম", "মাইকেল মধুসূদন দত্ত", "রবীন্দ্রনাথ ঠাকুর", "জসীম উদ্দীন"));
                add(new QuestionModule("বাংলাদেশের স্বাধীনতা যুদ্ধ কতদিন স্থায়ী ছিল?", "A", "৯ মাস", "১ বছর", "৬ মাস", "৩ বছর"));
                add(new QuestionModule("বাংলাদেশের প্রথম রাষ্ট্রপতি কে ছিলেন?", "B", "জিয়াউর রহমান", "শেখ মুজিবুর রহমান", "হোসেন শহীদ সোহরাওয়ার্দী", "আবুল কাসেম ফজলুল হক"));
                add(new QuestionModule("বাংলাদেশের জাতীয় পতাকার রং কী?", "D", "লাল এবং নীল", "সবুজ এবং হলুদ", "নীল এবং সাদা", "সবুজ এবং লাল"));
                add(new QuestionModule("বাংলাদেশের জাতীয় পশু কোনটি?", "A", "বেঙ্গল টাইগার", "হাতি", "হরিণ", "সিংহ"));
                add(new QuestionModule("বাংলাদেশের জাতীয় মসজিদের নাম কী?", "B", "বায়তুল মোকাররম", "শাহ জালাল মসজিদ", "চাঁদ মসজিদ", "মাটির মসজিদ"));
                add(new QuestionModule("বাংলাদেশের প্রথম মহিলা প্রধানমন্ত্রী কে ছিলেন?", "C", "শেখ হাসিনা", "খালেদা জিয়া", "কাজী জাহানারা বেগম", "নাজমা খান"));
            }
        };
        QuestionModule.createQuestionsForSubject("বাংলাদেশ", R.drawable.cat2, questions);


        //------------- Subject 3
        questions = new ArrayList(){
            {
                add(new QuestionModule("আইজ্যাক নিউটনের জন্ম সাল কত?", "A", "১৬৪৩", "১৬৬৬", "১৭০০", "১৭২৭"));
                add(new QuestionModule("আলোর গতি প্রতি সেকেন্ডে কত কিলোমিটার?", "D", "১৫০,০০০ কিমি", "২৯৯,০০০ কিমি", "৩৫৪,০০০ কিমি", "২৯৯,৭৯২ কিমি"));
                add(new QuestionModule("E = mc² সূত্রটি কে আবিষ্কার করেছেন?", "B", "নিউটন", "আইনস্টাইন", "গ্যালিলিও", "ফারাডে"));
                add(new QuestionModule("পৃথিবীর মাধ্যাকর্ষণ বলের মান কত?", "C", "৮.৮ মি/সেকেন্ড²", "৯.৫ মি/সেকেন্ড²", "৯.৮ মি/সেকেন্ড²", "১০.২ মি/সেকেন্ড²"));
                add(new QuestionModule("ভেক্টর এবং স্কেলার এর পার্থক্য কি?", "D", "মাত্রা", "দিক", "আকার", "দিক ও মাত্রা"));
                add(new QuestionModule("প্যাসকেল কোন রাশির একক?", "B", "শক্তি", "চাপ", "তাপমাত্রা", "ক্ষমতা"));
                add(new QuestionModule("কোনটি মৌলিক কণা নয়?", "A", "আলফা কণা", "ইলেকট্রন", "প্রোটন", "নিউট্রন"));
                add(new QuestionModule("চৌম্বকত্বের SI একক কি?", "D", "গড", "নিউটন", "ওয়াট", "টেসলা"));
                add(new QuestionModule("কোনটি কৃত্রিম উপগ্রহ?", "C", "চন্দ্র", "সূর্য", "স্পুটনিক ১", "মঙ্গল"));
                add(new QuestionModule("ধারণা করা হয় যে মহাবিশ্বের বিস্তার কীসের কারণে ঘটছে?", "A", "ডার্ক এনার্জি", "গ্রাভিটি", "ম্যাটার", "আলোর গতি"));
            }
        };
        QuestionModule.createQuestionsForSubject("পদার্থ বিজ্ঞান", R.drawable.cat3, questions);


        //------------- Subject 4
        questions = new ArrayList(){
            {
                add(new QuestionModule("পানি কোন রাসায়নিক সংকেত দ্বারা প্রতিনিধিত্ব করা হয়?", "B", "HO", "H₂O", "H₂O₂", "O₂"));
                add(new QuestionModule("রাসায়নিক বিক্রিয়ায় কেটালিস্টের ভূমিকা কী?", "A", "বিক্রিয়ার হার বৃদ্ধি করে", "বিক্রিয়ার হার কমায়", "পণ্য উৎপাদন বৃদ্ধি করে", "শক্তি উৎপাদন করে"));
                add(new QuestionModule("পারমাণবিক সংখ্যা কি নির্দেশ করে?", "D", "প্রোটনের সংখ্যা", "নিউট্রনের সংখ্যা", "ইলেকট্রনের সংখ্যা", "প্রোটন ও ইলেকট্রনের সংখ্যা"));
                add(new QuestionModule("অ্যাসিটিক অ্যাসিডের রাসায়নিক সংকেত কি?", "C", "CH₄", "C₂H₆", "C₂H₄O₂", "C₆H₁₂O₆"));
                add(new QuestionModule("সোডিয়াম ক্লোরাইড এর সাধারণ নাম কি?", "B", "বেকিং সোডা", "খাবার লবণ", "গ্লুকোজ", "অ্যাসিড"));
                add(new QuestionModule("কোন গ্যাসটি জীবাশ্ম জ্বালানি পোড়ানোর সময় বায়ুমণ্ডলে মুক্তি পায়?", "A", "কার্বন ডাই অক্সাইড", "অক্সিজেন", "নাইট্রোজেন", "হাইড্রোজেন"));
                add(new QuestionModule("pH এর মান ৭ এর বেশি হলে পদার্থটি কি হিসাবে পরিচিত?", "C", "অম্লীয়", "নিরপেক্ষ", "ক্ষারীয়", "অ-ধাতু"));
                add(new QuestionModule("গোল্ড বা সোনা কোন ধাতুর প্রতীক?", "A", "Au", "Ag", "Pb", "Fe"));
                add(new QuestionModule("রাসায়নিক বন্ধনে ইলেকট্রন শেয়ারিংকে কি বলা হয়?", "B", "আয়নিক বন্ধন", "সমযোজী বন্ধন", "ধাতব বন্ধন", "হাইড্রোজেন বন্ধন"));
                add(new QuestionModule("কোনটি একটি হ্যালোজেন উপাদান?", "D", "হাইড্রোজেন", "নাইট্রোজেন", "অক্সিজেন", "ক্লোরিন"));
            }
        };
        QuestionModule.createQuestionsForSubject("রসায়ন", R.drawable.cat4, questions);





        //------------- Subject 5
        questions = new ArrayList(){
            {
                add(new QuestionModule("মানবদেহে কতটি হাড় রয়েছে?", "B", "২০৬ টি", "২০৬ টি", "৩০০ টি", "১০৫ টি", "১৯৫ টি"));
                add(new QuestionModule("ডিএনএর পূর্ণরূপ কি?", "A", "ডিঅক্সিরাইবো নিউক্লিক অ্যাসিড", "ডিঅক্সি নিউক্লিক অ্যাসিড", "ডাইরাইবো নিউক্লিক অ্যাসিড", "ডাই অক্সাইড নিউক্লিক অ্যাসিড"));
                add(new QuestionModule("মানুষের দেহের বৃহত্তম অঙ্গ কোনটি?", "D", "হৃদপিণ্ড", "যকৃত", "ফুসফুস", "ত্বক"));
                add(new QuestionModule("কোনটি অণুজীব হিসেবে পরিচিত?", "C", "ফার্ন", "শেওলা", "ব্যাকটেরিয়া", "লতা"));
                add(new QuestionModule("মানবদেহের প্রধান শক্তির উৎস কোনটি?", "A", "গ্লুকোজ", "প্রোটিন", "লিপিড", "ভিটামিন"));
                add(new QuestionModule("মানবদেহের কোন অঙ্গে গ্লুকোজ সংরক্ষণ হয়?", "B", "মস্তিষ্ক", "যকৃত", "হৃৎপিণ্ড", "ফুসফুস"));
                add(new QuestionModule("প্লান্ট সেল বা উদ্ভিদ কোষের শক্তি উৎপাদন করে কোন অঙ্গাণু?", "D", "নিউক্লিয়াস", "রাইবোজোম", "সেন্ট্রিওল", "ক্লোরোপ্লাস্ট"));
                add(new QuestionModule("বায়োলজির জনক হিসেবে কাকে অভিহিত করা হয়?", "A", "অ্যারিস্টটল", "ডারউইন", "লিনিয়াস", "পাস্তুর"));
                add(new QuestionModule("কোন ভিটামিনটি রক্ত জমাট বাঁধায় সাহায্য করে?", "B", "ভিটামিন সি", "ভিটামিন কে", "ভিটামিন এ", "ভিটামিন ডি"));
                add(new QuestionModule("ম্যালেরিয়া রোগটি কী দ্বারা সৃষ্ট?", "C", "ব্যাকটেরিয়া", "ভাইরাস", "প্রটোজোয়া", "ফাংগাস"));
            }
        };
        QuestionModule.createQuestionsForSubject("জীব বিজ্ঞান", R.drawable.cat5, questions);




        //------------- Subject 6
        questions = new ArrayList(){
            {
                add(new QuestionModule("সূর্যের নিকটতম গ্রহ কোনটি?", "A", "বুধ", "শুক্র", "পৃথিবী", "মঙ্গল"));
                add(new QuestionModule("আমাদের গ্যালাক্সির নাম কী?", "B", "অ্যান্ড্রোমিডা", "মিল্কিওয়ে", "সোমব্রেরো", "উইর্লপুল"));
                add(new QuestionModule("চাঁদ পৃথিবীকে কতদিনে একবার প্রদক্ষিণ করে?", "C", "২৪ ঘন্টা", "৭ দিন", "২৭.৩ দিন", "৩০ দিন"));
                add(new QuestionModule("প্রথম মহাকাশচারী কে?", "B", "নিল আর্মস্ট্রং", "ইউরি গ্যাগারিন", "বাস অলড্রিন", "ভ্যালেনটিনা তেরেশকোভা"));
                add(new QuestionModule("পৃথিবীর নিকটতম নক্ষত্র কোনটি?", "D", "আলফা সেঞ্চৌরি", "বেটা সেঞ্চৌরি", "বার্নার্ড স্টার", "প্রক্সিমা সেঞ্চৌরি"));
                add(new QuestionModule("পৃথিবীর সবচেয়ে বড় গ্রহ কোনটি?", "C", "শনি", "মঙ্গল", "বৃহস্পতি", "শুক্র"));
                add(new QuestionModule("মহাবিশ্বের বয়স কত?", "B", "৫.৪ বিলিয়ন বছর", "১৩.৮ বিলিয়ন বছর", "১৫ বিলিয়ন বছর", "২০ বিলিয়ন বছর"));
                add(new QuestionModule("গ্রহাণু বেল্ট কোথায় অবস্থিত?", "C", "পৃথিবী ও মঙ্গলের মধ্যে", "শনি ও ইউরেনাসের মধ্যে", "মঙ্গল ও বৃহস্পতির মধ্যে", "বৃহস্পতি ও শনিের মধ্যে"));
                add(new QuestionModule("নক্ষত্রের আলো কীসের মাধ্যমে তৈরি হয়?", "A", "পারমাণবিক ফিউশন", "পারমাণবিক ফিশন", "রাসায়নিক বিক্রিয়া", "চুম্বকত্ব"));
                add(new QuestionModule("কোন গ্যালাক্সি আমাদের গ্যালাক্সির নিকটতম প্রতিবেশী?", "A", "অ্যান্ড্রোমিডা গ্যালাক্সি", "ত্রিভুজ গ্যালাক্সি", "ম্যাগেলানিক ক্লাউড", "কারিনা গ্যালাক্সি"));
            }
        };
        QuestionModule.createQuestionsForSubject("জ্যোতির্বিজ্ঞান", R.drawable.cat6, questions);


//new qustion
        questions = new ArrayList(){
            {
                add(new QuestionModule("বাংলাদেশের স্বাধীনতার ঘোষণা কখন করা হয়?", "B", "২৫ মার্চ ১৯৭১", "২৬ মার্চ ১৯৭১", "১৬ ডিসেম্বর ১৯৭১", "২১ ফেব্রুয়ারি ১৯৭১"));
                add(new QuestionModule("বাংলাদেশের প্রথম রাষ্ট্রপতি কে ছিলেন?", "A", "শেখ মুজিবুর রহমান", "জিয়াউর রহমান", "হুসেইন মুহাম্মদ এরশাদ", "ইয়াজউদ্দিন আহমেদ"));
                add(new QuestionModule("১৯৫২ সালের ভাষা আন্দোলনে কতজন শহীদ হন?", "C", "২ জন", "৩ জন", "৪ জন", "৫ জন"));
                add(new QuestionModule("বাংলাদেশের প্রথম প্রধানমন্ত্রী কে ছিলেন?", "B", "তাজউদ্দীন আহমদ", "শেখ মুজিবুর রহমান", "জিয়াউর রহমান", "বঙ্গবন্ধু শেখ মুজিবুর রহমান"));
                add(new QuestionModule("বাংলাদেশের সংবিধান কবে গৃহীত হয়?", "D", "২৬ মার্চ ১৯৭১", "১৬ ডিসেম্বর ১৯৭১", "৭ জুন ১৯৭২", "৪ নভেম্বর ১৯৭২"));
                add(new QuestionModule("বঙ্গবন্ধু শেখ মুজিবুর রহমানকে কবে হত্যা করা হয়?", "C", "১২ জানুয়ারি ১৯৭৫", "১৭ মার্চ ১৯৭৫", "১৫ আগস্ট ১৯৭৫", "২১ নভেম্বর ১৯৭৫"));
                add(new QuestionModule("১৯৭১ সালের মুক্তিযুদ্ধের সময় বাংলাদেশ কতটি সেক্টরে বিভক্ত ছিল?", "B", "৭ টি", "১১ টি", "১৩ টি", "১৫ টি"));
                add(new QuestionModule("মুক্তিযুদ্ধের সময় বাংলাদেশ সরকারের অস্থায়ী রাজধানী কোথায় ছিল?", "A", "মুজিবনগর", "কলকাতা", "ঢাকা", "চট্টগ্রাম"));
                add(new QuestionModule("বাংলাদেশের প্রথম অস্থায়ী রাষ্ট্রপতি কে ছিলেন?", "B", "তাজউদ্দীন আহমদ", "সৈয়দ নজরুল ইসলাম", "কাজী জাহান আরা", "আবদুল হামিদ"));
                add(new QuestionModule("১৯৭১ সালের মুক্তিযুদ্ধের সময় কে বাংলাদেশ সশস্ত্র বাহিনীর প্রধান ছিলেন?", "D", "এয়ার ভাইস মার্শাল এ কে খন্দকার", "মেজর জেনারেল এম এ মঞ্জুর", "মেজর জেনারেল এম এ গনি", "জেনারেল মুহাম্মদ আতাউল গণি ওসমানী"));
            }
        };
        QuestionModule.createQuestionsForSubject("বাংলাদেশের ইতিহাস", R.drawable.cat9, questions);




        questions = new ArrayList(){
            {
                add(new QuestionModule("পুণ্ড্রবর্ধন প্রাচীন বাংলার কোন অঞ্চলে অবস্থিত?", "A", "বগুড়া", "চট্টগ্রাম", "রাজশাহী", "সিলেট"));
                add(new QuestionModule("প্রাচীন বাংলার রাজধানী কোথায় ছিল?", "B", "চন্দ্রদ্বীপ", "গৌড়", "পুণ্ড্রনগর", "বিক্রমপুর"));
                add(new QuestionModule("মহাস্থানগড় কোন নদীর তীরে অবস্থিত?", "C", "গঙ্গা", "যমুনা", "করতোয়া", "মেঘনা"));
                add(new QuestionModule("প্রাচীন বাংলার বিখ্যাত রাজার নাম কী?", "D", "পশুপতি", "ধর্মপাল", "গোপাল", "শশাঙ্ক"));
                add(new QuestionModule("গুপ্ত সাম্রাজ্যের প্রতিষ্ঠাতা কে?", "A", "শ্রীগুপ্ত", "চন্দ্রগুপ্ত", "সমুদ্রগুপ্ত", "বিষ্ণুগুপ্ত"));
                add(new QuestionModule("পাল সাম্রাজ্যের প্রতিষ্ঠাতা কে ছিলেন?", "B", "গোপাল", "ধর্মপাল", "দেবপাল", "বিপ্রপাল"));
                add(new QuestionModule("কোন রাজবংশ বাংলায় দীর্ঘতম সময় ধরে শাসন করেছে?", "C", "মৌর্য", "গুপ্ত", "পাল", "সেন"));
                add(new QuestionModule("প্রাচীন বাংলায় বৌদ্ধ ধর্ম প্রচারের জন্য কোন রাজা বিখ্যাত ছিলেন?", "D", "গোপাল", "মিহিরাকুল", "শশাঙ্ক", "ধর্মপাল"));
                add(new QuestionModule("প্রাচীন বাংলার বিখ্যাত নগরী পান্ডুয়া কোথায় অবস্থিত?", "B", "রাজশাহী", "মালদা", "বগুড়া", "চাঁদপুর"));
                add(new QuestionModule("চন্দ্রগুপ্ত মৌর্য কোন খ্যাতনামা শিক্ষক দ্বারা শিক্ষিত হয়েছিলেন?", "C", "অরুণ", "বাসব", "চাণক্য", "পাণিনি"));
            }
        };
        QuestionModule.createQuestionsForSubject("প্রাচীন বাংলাদেশের ইতিহাস", R.drawable.cat10, questions);



        questions = new ArrayList(){
            {
                add(new QuestionModule("ইখতিয়ার উদ্দিন মুহম্মদ বখতিয়ার খলজি বাংলা জয় করেন কখন?", "B", "১১৮৬", "১২০৪", "১২২৭", "১২০৬"));
                add(new QuestionModule("সুলতান শামসুদ্দীন ইলিয়াস শাহ কোন বংশের প্রতিষ্ঠাতা?", "A", "ইলিয়াস শাহী বংশ", "হোসেন শাহী বংশ", "গনেশ বংশ", "খন্দকার বংশ"));
                add(new QuestionModule("হোসেন শাহী বংশের প্রতিষ্ঠাতা কে?", "B", "সুলতান আলাউদ্দীন হোসেন শাহ", "সুলতান গিয়াসউদ্দিন আজম শাহ", "সুলতান সিকান্দার শাহ", "সুলতান গিয়াসউদ্দিন বাহাদুর শাহ"));
                add(new QuestionModule("সুলতান গিয়াসউদ্দিন আজম শাহের শাসনকালে কোন বিখ্যাত সাহিত্যিক তৎকালীন বাংলায় এসেছিলেন?", "C", "আমির খসরু", "ইবনে বতুতা", "আল বিরুনি", "ফিরদৌসি"));
                add(new QuestionModule("বাংলায় প্রথম মুসলিম শাসন ব্যবস্থা প্রতিষ্ঠিত হয় কোন বংশের শাসনামলে?", "D", "সেন বংশ", "গুপ্ত বংশ", "মৌর্য বংশ", "তুঘলক বংশ"));
                add(new QuestionModule("বাংলার শেষ স্বাধীন সুলতান কে ছিলেন?", "C", "ইলিয়াস শাহ", "আলাউদ্দীন হোসেন শাহ", "দাউদ খাঁ কররানি", "ইস্কন্দর শাহ"));
                add(new QuestionModule("বখতিয়ার খলজি কোন রাজবংশকে পরাজিত করে বাংলা দখল করেন?", "B", "পাল বংশ", "সেন বংশ", "গুপ্ত বংশ", "মৌর্য বংশ"));
                add(new QuestionModule("মধ্যযুগের বাংলায় কোন সুলতান নৌবাহিনী প্রতিষ্ঠা করেছিলেন?", "A", "শামসুদ্দীন ইলিয়াস শাহ", "গিয়াসউদ্দিন আজম শাহ", "আলাউদ্দীন হোসেন শাহ", "সিকান্দার শাহ"));
                add(new QuestionModule("ইবনে বতুতা কোন সুলতানের শাসনামলে বাংলায় এসেছিলেন?", "B", "ইলিয়াস শাহ", "ফখরুদ্দীন মুবারক শাহ", "নাসিরুদ্দীন মাহমুদ", "গিয়াসউদ্দিন বাহাদুর শাহ"));
                add(new QuestionModule("মধ্যযুগের কোন বিখ্যাত সুফি সাধক বাংলায় ইসলাম প্রচারে গুরুত্বপূর্ণ ভূমিকা পালন করেন?", "C", "বাবা আদম শাহ", "শাহ মখদুম", "শাহ জালাল", "শাহ পরান"));
            }
        };
        QuestionModule.createQuestionsForSubject("মধ্যযুগের বাংলাদেশের ইতিহাস", R.drawable.cat11, questions);



        questions = new ArrayList(){
            {
                add(new QuestionModule("সোনারগাঁও জাদুঘর বিশ্বের কোন শহরে অবস্থিত?", "C", "ঢাকা", "রাজশাহী", "খুলনা", "চট্টগ্রাম"));
                add(new QuestionModule("সুনামগঞ্জে অবস্থিত বুদ্ধবিহার কোন নদীর তীরে অবস্থিত?", "B", "ব্রহ্মপুত্রা", "তীর্ণপুরা", "মেঘনা", "পদ্মা"));
                add(new QuestionModule("লালমনিরহাটের সোমাপুর বৌদ্ধ বিহার কতটি গোমতী বিহারের মধ্যে অবস্থিত?", "D", "১০০", "২৫", "৫০", "১৫০"));
                add(new QuestionModule("মহাস্থানগড়ে কোন ধর্মীয় স্থানটির অবশেষ আবিষ্কৃত হয়?", "A", "সোমপুর বিহার", "পাহাড় গোপালপুর বিহার", "লালময় বিহার", "আমগড়িয়া"));
                add(new QuestionModule("পাহাড় গোপালপুর বিহার কোন জেলার অংশে অবস্থিত?", "C", "নোয়াখালী", "চাঁদপুর", "চট্টগ্রাম", "বরিশাল"));
                add(new QuestionModule("পহাড়া রাজবাড়ী কোথায় অবস্থিত?", "D", "চট্টগ্রাম", "কুমিল্লা", "নোয়াখালী", "বান্দরবান"));
                add(new QuestionModule("গৌড়ের মহাবিহার কোথায় অবস্থিত?", "A", "মালদা", "সিলেট", "ঢাকা", "রাজশাহী"));
                add(new QuestionModule("পাঁচগড় গর্জ বিশ্বের কোন মহাবিহারের নামে পরিচিত?", "B", "মহাস্থানগড়", "পাহাড় গোপালপুর", "চোট্টরগ্রাম", "সোমপুর বিহার"));
                add(new QuestionModule("লালমনিরহাটে অবস্থিত বিশ্বের কোন প্রাচীন মসজিদ বাংলাদেশের সর্বোচ্চ মসজিদ হিসেবে পরিচিত?", "C", "কুসুম মসজিদ", "শাহী মসজিদ", "গৌর লক্ষ্মীপুর মসজিদ", "ষাট গম্বুজ মসজিদ"));
                add(new QuestionModule("শালবন বিহার কোথায় অবস্থিত?", "D", "রাজশাহী", "চট্টগ্রাম", "সিলেট", "রংপুর"));
            }
        };
        QuestionModule.createQuestionsForSubject("বাংলাদেশের ঐতিহাসিক স্থান", R.drawable.cat7, questions);


        questions = new ArrayList(){
            {
                add(new QuestionModule("দ্বিঘাত সমীকরণের সাধারণ সমাধান কি?", "B", "সমাধান নেই", "দুটি সমীকরণের মধ্যে সাধারণ সমাধান", "অসমাধান", "কোনটিও নয়"));
                add(new QuestionModule("সর্বোচ্চ মান যার জন্য sin x + cos x = 1 সমীকরণের সমাধান সম্ভব?", "C", "১", "২", "√2", "√3"));
                add(new QuestionModule("নিচের কোন সংখ্যাটি একটি পূর্ণসংখ্যা নয়?", "A", "√2", "৫", "৭", "১২"));
                add(new QuestionModule("৪ এর অনুপাতে ৬০ এর পূর্ণাংক কত?", "D", "২৫", "১২", "১৫", "২০"));
                add(new QuestionModule("কোনটি বাস্তব সংখ্যা?", "B", "i", "২", "√-১", "৫"));
                add(new QuestionModule("যদি x + y = ১ এবং x^2 + y^2 = ২ হয়, তবে xy এর মান কত?", "C", "১", "২", "১/২", "১/৪"));
                add(new QuestionModule("যদি a + b = ৫ এবং a^2 + b^2 = ২৫ হয়, তবে ab এর মান কত?", "D", "১", "৩", "৫", "১০"));
                add(new QuestionModule("x^2 + ৬x + ১২ = ০ সমীকরণের সমাধান কি?", "A", "-৪, -২", "৪, ২", "-৪, ২", "২, -২"));
                add(new QuestionModule("একটি বর্গের বাহুর দৈর্ঘ্য ১২ একক হলে, অংকুভস কত?", "B", "৬", "১২", "২৪", "৩৬"));
                add(new QuestionModule("কোনটি অসমতা সমাধান করে?", "C", "|x - ৩| = ৭", "|x + ৩| = -৭", "|x - ৩| = -৭", "|x + ৩| = ৭"));
            }
        };
        QuestionModule.createQuestionsForSubject("গণিত", R.drawable.cat12, questions);



        questions = new ArrayList(){
            {
                add(new QuestionModule("একটি বৃত্তের কেন্দ্র ০, ০ অবস্থিত এবং এর ব্যাসার্ধ ৫ একক। একটি বিন্দু (৪, -৩) এর থেকে বৃত্তের অংকুভস কত?", "B", "২", "৩", "৪", "৫"));
                add(new QuestionModule("একটি বৃত্তের কেন্দ্র ০, ০ অবস্থিত এবং এর ব্যাসার্ধ ৫ একক হলে, এর ব্যাসার্ধ সহ কোণের মান কত?", "C", "৩০°", "৪৫°", "৬০°", "৯০°"));
                add(new QuestionModule("একটি ত্রিভুজের তিনটি শীর্ষবিন্দু একই সরলরেখা বরাবর অবস্থিত। ত্রিভুজের একটি বাহুর দৈর্ঘ্য ৮ একক এবং অপর দুই বাহুর দৈর্ঘ্য ১০ একক। ত্রিভুজের অংকুভস কত?", "B", "১০", "১২", "১৬", "১৮"));
                add(new QuestionModule("একটি ত্রিভুজের পরিমাপ ২৫ একক এবং এর একটি বাহুর দৈর্ঘ্য ১০ একক। ত্রিভুজের অপর দুই বাহুর দৈর্ঘ্য কত?", "A", "৫", "৮", "১২", "১৫"));
                add(new QuestionModule("একটি ত্রিভুজের একটি কোণের মান ৪৫° এবং অপর দুই কোণের মান সমান। ত্রিভুজের পরিমাপ কত?", "C", "৯০°", "১২০°", "১৮০°", "২৭০°"));
                add(new QuestionModule("একটি ত্রিভুজের প্রত্যেকটি বাহুর দৈর্ঘ্য সমান হলে, তার কোণগুলো কতটি সমান?", "A", "৩", "২", "১", "বিশেষ ক্ষেত্রে তারা সমান হবে না"));
                add(new QuestionModule("একটি বৃত্তের ব্যাসার্ধ ১০ একক হলে, এর ব্যাসার্ধ সহ কোণের মান কত?", "C", "৩০°", "৪৫°", "৬০°", "৯০°"));
                add(new QuestionModule("একটি বৃত্তের কেন্দ্র ০, ০ অবস্থিত এবং এর ব্যাসার্ধ ৫ একক। একটি বিন্দু (৪, -৩) এর থেকে বৃত্তের অংকুভস কত?", "B", "২", "৩", "৪", "৫"));
                add(new QuestionModule("একটি বৃত্তের ব্যাসার্ধ ১০ একক। বৃত্তের পরিধি কত?", "C", "৫π", "১০π", "২০π", "২৫π"));
                add(new QuestionModule("একটি বৃত্তের ব্যাসার্ধ ১২ একক। বৃত্তের ক্ষেত্রফল কত?", "B", "১২π", "২৪π", "৩৬π", "৪৮π"));

            }
        };
        QuestionModule.createQuestionsForSubject("গণিত", R.drawable.cat13, questions);





        questions = new ArrayList(){
            {
                add(new QuestionModule("ইসলামের পবিত্র গ্রন্থের নাম কী?", "A", "কুরআন", "বাইবেল", "গীতা", "তোরাহ"));
                add(new QuestionModule("ইসলামের শেষ নবীর নাম কী?", "B", "ইবরাহিম", "মুহাম্মদ", "মুসা", "ইসা"));
                add(new QuestionModule("মুসলমানদের প্রার্থনার স্থান কী বলে?", "C", "মন্দির", "গীর্জা", "মসজিদ", "সিনাগগ"));
                add(new QuestionModule("রমজান মাসে মুসলমানরা কি করে?", "A", "রোজা রাখে", "নবীকে স্মরণ করে", "হজ্জ পালন করে", "যাকাত দেয়"));
                add(new QuestionModule("ইসলামের পবিত্র শহরের নাম কী?", "B", "জেরুজালেম", "মক্কা", "মদিনা", "কারবালা"));
                add(new QuestionModule("মুসলমানদের প্রধান ধর্মীয় উৎসবের একটি নাম কী?", "D", "হোলি", "ক্রিসমাস", "দুর্গাপূজা", "ঈদ"));
                add(new QuestionModule("মুসলমানরা দিনে কত বার নামাজ পড়ে?", "C", "তিনবার", "চারবার", "পাঁচবার", "ছয়বার"));
                add(new QuestionModule("ইসলামের প্রথম খলিফা কে ছিলেন?", "A", "আবু বকর", "উমর", "উসমান", "আলী"));
                add(new QuestionModule("কাবা শরিফ কোথায় অবস্থিত?", "B", "মদিনা", "মক্কা", "জেরুজালেম", "কায়রো"));
                add(new QuestionModule("কোন মাসে মুসলমানরা হজ্জ পালন করে?", "D", "মহররম", "রজব", "রবিউল আউয়াল", "জিলহজ্জ"));

            }
        };

        QuestionModule.createQuestionsForSubject("ইসলাম ধর্ম", R.drawable.islam, questions);


        questions = new ArrayList(){
            {
                add(new QuestionModule("খ্রিস্টানদের পবিত্র গ্রন্থের নাম কী?", "B", "তোরাহ", "বাইবেল", "গীতা", "কুরআন"));
                add(new QuestionModule("খ্রিস্টানদের প্রার্থনার স্থান কী বলে?", "D", "মন্দির", "মসজিদ", "সিনাগগ", "গীর্জা"));
                add(new QuestionModule("খ্রিস্টান ধর্মের প্রতিষ্ঠাতা কে?", "A", "যীশু খ্রিস্ট", "মহাত্মা গান্ধী", "গৌতম বুদ্ধ", "মুহাম্মদ"));
                add(new QuestionModule("যীশু খ্রিস্ট কোথায় জন্মগ্রহণ করেন?", "B", "জেরুজালেম", "বেথলেহেম", "নাজারেথ", "কাফার্নাহুম"));
                add(new QuestionModule("খ্রিস্টান ধর্মের প্রধান ধর্মীয় উৎসব কোনটি?", "C", "দুর্গাপূজা", "ঈদ", "ক্রিসমাস", "হোলি"));
                add(new QuestionModule("খ্রিস্টান ধর্মের প্রধান উপাসনা দিন কোনটি?", "A", "রবিবার", "শনিবার", "শুক্রবার", "বৃহস্পতিবার"));
                add(new QuestionModule("খ্রিস্টান ধর্মমতে, যীশু খ্রিস্ট কবে পুনরুত্থান করেন?", "D", "ক্রিসমাসে", "পাম সানডেতে", "গুড ফ্রাইডেতে", "ইস্টার সানডেতে"));
                add(new QuestionModule("বাইবেলের নতুন নিয়মের প্রথম বইয়ের নাম কী?", "C", "লেবিটিকাস", "সংখ্যাপাঠ", "মথি", "উপদেশক"));
                add(new QuestionModule("যীশু খ্রিস্টের মাতার নাম কী?", "B", "মার্থা", "মারিয়া", "এলিজাবেথ", "আনা"));
                add(new QuestionModule("খ্রিস্টান ধর্মের অন্যতম প্রধান অনুসারী পলের আসল নাম কী ছিল?", "A", "সাউল", "পিটার", "জন", "অ্যান্ড্রু"));
            }
        };
        QuestionModule.createQuestionsForSubject("খ্রিস্ট ধর্ম", R.drawable.kristhan, questions);


        questions = new ArrayList(){
            {
                add(new QuestionModule("হিন্দুদের পবিত্র গ্রন্থের নাম কী?", "C", "বাইবেল", "কুরআন", "ভগবত গীতা", "তোরাহ"));
                add(new QuestionModule("হিন্দুদের প্রার্থনার স্থান কী বলে?", "A", "মন্দির", "মসজিদ", "গীর্জা", "সিনাগগ"));
                add(new QuestionModule("হিন্দু ধর্মের প্রধান দেবতা কে?", "B", "ব্রহ্মা", "বিষ্ণু", "শিব", "গণেশ"));
                add(new QuestionModule("হিন্দু ধর্মের প্রধান উৎসবের একটি নাম কী?", "D", "ক্রিসমাস", "ঈদ", "হানুক্কাহ", "দুর্গাপূজা"));
                add(new QuestionModule("হিন্দুদের সবচেয়ে পবিত্র নদীর নাম কী?", "B", "ইয়ামুনা", "গঙ্গা", "নর্মদা", "গোদাবরী"));
                add(new QuestionModule("হিন্দুদের প্রধান উপাসনার স্থান কোনটি?", "C", "গীর্জা", "মসজিদ", "মন্দির", "গুরদুয়ারা"));
                add(new QuestionModule("হিন্দু ধর্মমতে, কৃষ্ণ কোন মহাকাব্যের নায়ক?", "A", "মহাভারত", "রামায়ণ", "বেদ", "পুরাণ"));
                add(new QuestionModule("হিন্দু ধর্মের সৃষ্টি তত্ত্বের প্রধান দেবতা কে?", "A", "ব্রহ্মা", "বিষ্ণু", "শিব", "ইন্দ্র"));
                add(new QuestionModule("হিন্দুদের সবচেয়ে বড় মহাকাব্য কোনটি?", "D", "গীতা", "উপনিষদ", "বেদ", "রামায়ণ"));
                add(new QuestionModule("হিন্দু ধর্মের প্রধান ধর্মীয় স্থান কোনটি?", "B", "অযোধ্যা", "বারাণসী", "মথুরা", "দ্বারকা"));
            }
        };
        QuestionModule.createQuestionsForSubject("হিন্দু ধর্ম", R.drawable.hindu, questions);


        questions = new ArrayList(){
            {
                add(new QuestionModule("ইহুদিদের পবিত্র গ্রন্থের নাম কী?", "A", "তোরাহ", "বাইবেল", "কুরআন", "গীতা"));
                add(new QuestionModule("ইহুদিদের প্রার্থনার স্থান কী বলে?", "C", "মসজিদ", "গীর্জা", "সিনাগগ", "মন্দির"));
                add(new QuestionModule("ইহুদি ধর্মের প্রতিষ্ঠাতা কে?", "B", "মুহাম্মদ", "মূসা", "যীশু", "আব্রাহাম"));
                add(new QuestionModule("ইহুদিদের প্রধান ধর্মীয় উৎসবের একটি নাম কী?", "D", "ক্রিসমাস", "ঈদ", "হোলি", "হনুক্কাহ"));
                add(new QuestionModule("ইহুদি ধর্মের প্রধান উপাসনার দিন কোনটি?", "B", "রবিবার", "শনিবার", "শুক্রবার", "বৃহস্পতিবার"));
                add(new QuestionModule("ইহুদিদের পবিত্র শহরের নাম কী?", "A", "জেরুজালেম", "মক্কা", "রোম", "বারাণসী"));
                add(new QuestionModule("তোরাহ কতটি বই নিয়ে গঠিত?", "C", "তিনটি", "চারটি", "পাঁচটি", "ছয়টি"));
                add(new QuestionModule("ইহুদিদের প্রধান উপাসনার স্থান কোনটি?", "C", "মন্দির", "মসজিদ", "সিনাগগ", "গীর্জা"));
                add(new QuestionModule("ইহুদি ধর্মের প্রধান সৃষ্টিকর্তা কে?", "A", "ইহোবা", "ব্রহ্মা", "আল্লাহ", "যীশু"));
                add(new QuestionModule("ইহুদি ধর্মের বিশেষ প্রার্থনার টুপি কী নামে পরিচিত?", "B", "তালিত", "কিপ্পাহ", "হিজাব", "পাগড়ি"));
            }
        };
        QuestionModule.createQuestionsForSubject("ইহুদি ধর্ম", R.drawable.ihudi, questions);


        questions = new ArrayList(){
            {
                add(new QuestionModule("বৌদ্ধদের পবিত্র গ্রন্থের নাম কী?", "B", "বেদ", "ত্রিপিটক", "গীতা", "কুরআন"));
                add(new QuestionModule("বৌদ্ধদের প্রার্থনার স্থান কী বলে?", "C", "মন্দির", "সিনাগগ", "বিহার", "গীর্জা"));
                add(new QuestionModule("বৌদ্ধ ধর্মের প্রতিষ্ঠাতা কে?", "A", "গৌতম বুদ্ধ", "মহাবীর", "শংকরাচার্য", "কনফুসিয়াস"));
                add(new QuestionModule("বৌদ্ধ ধর্মের প্রধান ধর্মীয় উৎসবের নাম কী?", "D", "হনুক্কাহ", "দুর্গাপূজা", "ক্রিসমাস", "বুদ্ধ পূর্ণিমা"));
                add(new QuestionModule("বৌদ্ধ ধর্মমতে, গৌতম বুদ্ধের জন্মস্থান কোথায়?", "B", "ভারানসি", "লুম্বিনি", "বোধগয়া", "কুশীনগর"));
                add(new QuestionModule("বৌদ্ধদের প্রধান ধর্মীয় উপাসনার দিন কোনটি?", "A", "পূর্ণিমা", "অমাবস্যা", "রবিবার", "শুক্রবার"));
                add(new QuestionModule("বৌদ্ধ ধর্মের কোন শাখা তিব্বতে সবচেয়ে বেশি প্রচলিত?", "C", "থেরবাদ", "মহাযান", "বজ্রযান", "জেন"));
                add(new QuestionModule("গৌতম বুদ্ধের মূল শিক্ষার সারাংশ কী?", "A", "চতুরার্য সত্য", "কর্ম", "ভক্তি", "জ্ঞান"));
                add(new QuestionModule("বৌদ্ধ ধর্মের মূল সাধন পদ্ধতির নাম কী?", "B", "যজ্ঞ", "ধ্যান", "ভক্তি", "সংকীর্তন"));
                add(new QuestionModule("বৌদ্ধ ধর্মের মূল নীতিসমূহের মধ্যে অন্যতম একটি কী?", "D", "অহিংসা", "সত্য", "অস্তেয়", "সম্যক আচরণ"));
            }
        };
        QuestionModule.createQuestionsForSubject("বৌদ্ধ ধর্ম", R.drawable.buddo, questions);



    }
//====================================================================

}
