package com.aminsoftware.dictionary;



import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.AdapterStatus;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity2 extends AppCompatActivity {

    AutoCompleteTextView autoCompleteTextView;
    ImageButton imageButton , imageButton1 , btnSpeak;
    TextToSpeech tts;
    ListView listView;
    DatabaseHelper dbHelper;
    ArrayList<HashMap<String, String>> arrayList;
    ArrayList<String> suggestions;

    HashMap<String, String> hashMap;


    AdView adView;
    NavigationView nav;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    Toolbar toolbar;


    private static final int REQUEST_CODE_SPEECH_INPUT = 1000;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);




        autoCompleteTextView = findViewById(R.id.autoCompleteTextView);
        imageButton = findViewById(R.id.imagebutton);
        imageButton1 = findViewById(R.id.imagebutton1);
        btnSpeak = findViewById(R.id.btnSpeak);

        listView = findViewById(R.id.listView);
        dbHelper = new DatabaseHelper(this);
        loadData(dbHelper.getAllData());
        listView.setVisibility(View.GONE);

        loadFullscreenAd();

        btnSpeak.setOnClickListener(v -> startVoiceRecognition());
        //====================================================================
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        nav = findViewById(R.id.navmenu);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);

        toggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();




        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int itemId = item.getItemId();
                if (itemId == R.id.menu_bcs) {
                    Toast.makeText(getApplicationContext(), "Loading...", Toast.LENGTH_SHORT).show();
                    Intent myIntent5 = new Intent(MainActivity2.this, MainActivity.class);
                    startActivity(myIntent5);

                    if (mInterstitialAd != null) {
                        mInterstitialAd.show(MainActivity2.this);
                    }

                  } else if (itemId == R.id.menu_qrcode) {
                    Toast.makeText(getApplicationContext(), "Loading...", Toast.LENGTH_SHORT).show();
                    Intent myIntent3 = new Intent(MainActivity2.this, MainActivity3.class);
                    startActivity(myIntent3);

                    if (mInterstitialAd != null) {
                        mInterstitialAd.show(MainActivity2.this);
                    }

                } else if (itemId == R.id.menu_ocr) {
                    Toast.makeText(getApplicationContext(), "Loading...", Toast.LENGTH_SHORT).show();
                    Intent myIntent4 = new Intent(MainActivity2.this, MainActivity5.class);
                    startActivity(myIntent4);

                    if (mInterstitialAd != null) {
                        mInterstitialAd.show(MainActivity2.this);
                    }

                } else if (itemId==R.id.pilicy){

                    Toast.makeText(getApplicationContext(), "Loading...", Toast.LENGTH_SHORT).show();
                    Intent myIntent4 = new Intent(MainActivity2.this, MainActivity4.class);
                    startActivity(myIntent4);

                    if (mInterstitialAd != null) {
                        mInterstitialAd.show(MainActivity2.this);
                    }

                }

                    return true;
                }

        });
    //=====================================================================

        // Set up the AutoCompleteTextView
        suggestions = new ArrayList<>();
        for (HashMap<String, String> wordData : arrayList) {
            suggestions.add(wordData.get("word"));
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, suggestions);
        autoCompleteTextView.setAdapter(adapter);

        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedWord = (String) parent.getItemAtPosition(position);
                autoCompleteTextView.setText(selectedWord);
                loadData(dbHelper.searchData(selectedWord));
                listView.setVisibility(View.VISIBLE);
            }
        });

        autoCompleteTextView.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().isEmpty()) {
                    listView.setVisibility(View.GONE);
                } else {
                    listView.setVisibility(View.VISIBLE);
                    loadData(dbHelper.searchData(s.toString()));
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  imageButton1.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
          autoCompleteTextView.setText("");

      }
  });


        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        if (status == TextToSpeech.SUCCESS) {
                            tts.setLanguage(Locale.UK);
                            tts.setSpeechRate(1.0f);
                            tts.speak(autoCompleteTextView.getText().toString(), TextToSpeech.QUEUE_ADD, null);
                        }
                    }
                });
            }
        });

//==================================================================================================
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
                Map<String, AdapterStatus> statusMap = initializationStatus.getAdapterStatusMap();
                for (String adapterClass : statusMap.keySet()) {
                    AdapterStatus status = statusMap.get(adapterClass);
                    Log.d("MyApp", String.format(
                            "Adapter name: %s, Description: %s, Latency: %d",
                            adapterClass, status.getDescription(), status.getLatency()));
                }
                // Start loading ads here...
                adView=findViewById(R.id.adView);
                MobileAds.initialize(getBaseContext(), new OnInitializationCompleteListener() {
                    @Override
                    public void onInitializationComplete( InitializationStatus initializationStatus) {

                    }
                });

                AdRequest adRequest=new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        });
//====================================================================================
    }
//=========================================================================================
    InterstitialAd mInterstitialAd;
    int FULLSCREEN_AD_LOAD_COUNT=0;
    private void loadFullscreenAd(){

        //Requesting for a fullscreen Ad
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this,getString(R.string.admob_INTERSTITIAL_UNIT_ID), adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                mInterstitialAd = interstitialAd;

                //Fullscreen callback || Requesting again when an ad is shown already
                mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(){
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when fullscreen content is dismissed.
                        //User dismissed the previous ad. So we are requesting a new ad here
                        FULLSCREEN_AD_LOAD_COUNT++;

                        if(FULLSCREEN_AD_LOAD_COUNT<1)
                            loadFullscreenAd();
                        Log.d("FULLSCREEN_AD", ""+FULLSCREEN_AD_LOAD_COUNT);

                    }

                }); // FullScreen Callback Ends here


            }
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                // Handle the error
                mInterstitialAd = null;
            }

        });

    }
//=====================================================================
//=================================

    public void loadData(Cursor cursor) {
        if (cursor != null && cursor.getCount() > 0) {
            arrayList = new ArrayList<>();
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String word = cursor.getString(1);
                String meaning = cursor.getString(2);
                String partsOfSpeech = cursor.getString(3);
                String example = cursor.getString(4);

                hashMap = new HashMap<>();
                hashMap.put("id", "" + id);
                hashMap.put("word", "" + word);
                hashMap.put("meaning", "" + meaning);
                hashMap.put("partsOfSpeech", "" + partsOfSpeech);
                hashMap.put("example", "" + example);
                arrayList.add(hashMap);
            }
            listView.setAdapter(new MyAdapter());
        }
    }

    public class MyAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return arrayList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View myView = inflater.inflate(R.layout.item, parent, false);

            TextView tvWord = myView.findViewById(R.id.tvWord);
            TextView tvMeaning = myView.findViewById(R.id.tvMeaning);
            TextView tvExample = myView.findViewById(R.id.tvExample);

            hashMap = arrayList.get(position);
            String word = hashMap.get("word");
            String meaning = hashMap.get("meaning");
            String partsOfSpeech = hashMap.get("partsOfSpeech");
            String example = hashMap.get("example");

            tvWord.setText(word + " (" + partsOfSpeech + ")");
            tvMeaning.setText(meaning);
            tvExample.setText(example);

            return myView;
        }
    }
//=============================================================================

    private void startVoiceRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
        } else {
           autoCompleteTextView.setText("Your device doesn't support speech input");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SPEECH_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                autoCompleteTextView.setText(result.get(0));
            }
        }
    }
//===========================================================================================
@SuppressLint("MissingSuperCall")
@Override
public void onBackPressed() {
    // Create an AlertDialog.Builder
    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity2.this);
    builder.setTitle("Confirm Exit?");
    builder.setMessage("Do you really want to exit?");

    // Set the negative button
    builder.setNegativeButton("No Thanks", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialogInterface, int i) {
            // Dismiss the dialog when "No Thanks" is clicked
            dialogInterface.dismiss();
        }
    });

    // Set the positive button
    builder.setPositiveButton("Yes Exit", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialogInterface, int i) {
            // Dismiss the dialog and finish the activity when "Yes Exit" is clicked
            dialogInterface.dismiss();
            finishAffinity();
        }
    });

    // Show the dialog
    builder.show();
}

//=========================================================
}