package com.aminsoftware.dictionary;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

public class DatabaseHelper extends SQLiteAssetHelper {
    public DatabaseHelper(Context context) {
        super(context, "dictionary.db", null, 1);
    }

//====================================================================
    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Dictionary", null);
        return cursor;
    }

    //=================================================================
    public Cursor searchData(String word) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Use parameterized query to prevent SQL injection and handle special characters
        Cursor cursor = db.rawQuery("SELECT * FROM Dictionary WHERE word LIKE ?", new String[]{word});
        return cursor;

        // Cursor cursor = db.rawQuery("SELECT * FROM Dictionary WHERE word LIKE '" + word + "%'", null);
    }
//============================================================================
}
